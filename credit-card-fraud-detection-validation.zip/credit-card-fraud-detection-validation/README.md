
# 🕵️‍♀️ Credit Card Fraud Detection – Label Validation Report

## 📌 Project Goal
Build a Power BI dashboard to explore fraudulent transaction patterns in a public dataset.  
However, after cleaning and validation, it was discovered that the dataset contains **no fraud labels** (`is_fraud = 1`), which highlights a real-world data integrity issue.

## 🛠️ Tools Used
- Excel (Data Cleaning)
- Power BI Desktop (Dashboard & Visualization)
- GitHub (Documentation & Version Control)

## 🧪 Key Findings

| Issue | Outcome |
|-------|---------|
| Fraud label (`is_fraud = 1`) present? | ❌ No — all values are 0 |
| Dashboard insights possible? | ✅ Transaction trends, categories, state-level summaries |
| Model-ready dataset? | ❌ Not suitable for fraud prediction or classification |

## 🤔 Lessons Learned
- Always validate key label columns before analysis
- Clean data ≠ usable data — integrity matters
- Telling the story of data *limitations* is just as valuable as building a perfect model

## 📫 Connect
- [LinkedIn](#)
